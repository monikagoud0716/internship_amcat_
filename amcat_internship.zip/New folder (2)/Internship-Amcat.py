#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import warnings
warnings.filterwarnings("ignore")


# In[2]:


df=pd.read_csv(r"C:\Users\K. Sridhar Goud\Downloads\data.xlsx - Sheet1.csv")


# In[3]:


df


# In[4]:


df.info()


# In[5]:


df.drop("Unnamed: 0",axis=1,inplace=True)


# In[6]:


df


# In[7]:


df.info()


# In[8]:


df["DOJ"].unique()


# In[9]:


df["DOJ"]=pd.to_datetime(df["DOJ"])


# In[10]:


df.info()


# In[11]:


df["DOB"]=pd.to_datetime(df["DOB"])


# In[12]:


df.columns


# In[13]:


df[['ComputerProgramming',
       'ElectronicsAndSemicon', 'ComputerScience', 'MechanicalEngg',
       'ElectricalEngg', 'TelecomEngg', 'CivilEngg']]=df[['ComputerProgramming',
       'ElectronicsAndSemicon', 'ComputerScience', 'MechanicalEngg',
       'ElectricalEngg', 'TelecomEngg', 'CivilEngg']].replace(-1,np.nan)


# In[14]:


df


# In[15]:


df.info()


# In[16]:


df["DOL"]=df["DOL"].replace("present","1/1/24 0:00")


# In[17]:


df


# In[18]:


df["DOL"]=pd.to_datetime(df["DOL"])


# In[19]:


df.info()


# In[20]:


df["Designation"].unique()


# In[21]:


df.duplicated().sum()


# In[22]:


df.describe()


# In[23]:


df.describe(include="object")


# In[24]:


df["Salary"].sum()


# In[25]:


df.corr(numeric_only=True)


# In[26]:


df


# In[27]:


df["Designation"].value_counts().reset_index()


# In[28]:


df["JobCity"].value_counts().reset_index()


# In[29]:


df[df["JobCity"]=="-1"]


# In[30]:


df["JobCity"]=df["JobCity"].replace("-1","Bangalore")


# In[31]:


df["Gender"].unique()


# In[32]:


min(df["10percentage"])


# In[33]:


max(df["10percentage"])


# In[34]:


df["10board"]=df["10board"].replace("0","cbse")


# In[35]:


df["10board"].value_counts()


# In[36]:


df["10board"].str.contains("ssc").sum()


# In[37]:


df[df["10board"]=="ssc"]


# In[38]:


df["10board"]=df["10board"].replace("ssc","state board")


# In[39]:


df["10board"]=df["10board"].replace("up board","state board")


# In[40]:


df["10board"]=df["10board"].replace("matriculation","state board")


# In[41]:


df["10board"]=df["10board"].replace("rbse","state board")


# In[42]:


df["10board"]=df["10board"].replace("board of secondary education","state board")


# In[43]:


df["10board"]=df["10board"].replace("up","state board")


# In[44]:


df["10board"]=df["10board"].replace("mp board","state board")


# In[45]:


df["10board"]=df["10board"].replace("wbbse","state board")


# In[46]:


df["10board"]=df["10board"].replace("central board of secondary education","cbse")


# In[47]:


df["10board"]=df["10board"].replace("kseeb","state board")


# In[48]:


df["10board"]=df["10board"].replace("upboard","state board")


# In[49]:


df["10board"].unique()


# In[50]:


df["10board"]=df["10board"].replace("icse board","icse")


# In[51]:


df["10board"]=df["10board"].replace("international board","icse")


# In[52]:


df["10board"]=df["10board"].replace("cbse[gulf zone]","cbse")


# In[53]:


df["10board"]=df["10board"].replace("state","state board")


# In[54]:


df["10board"]=df["10board"].replace("jawahar navodaya vidyalaya","cbse")


# In[55]:


df["10board"]=df["10board"].replace("cicse","icse")


# In[56]:


def board(x):
    if (x=="cbse"):
        return "cbse"
    elif x=="icse":
        return "icse"
    
    else:
        return "state borad"


# In[57]:


board("cbse")


# In[58]:


df["10board"]=df["10board"].apply(board)


# In[59]:


df['10board'].value_counts()


# In[60]:


df["12graduation"].unique()


# In[61]:


df.columns


# In[62]:


max(df["12percentage"])


# In[63]:


df["12board"].value_counts()


# In[64]:


df["12board"].unique()


# In[65]:


df.columns


# In[66]:


sum(df["CollegeID"]==df["CollegeCityID"])


# In[67]:


df.drop("CollegeCityID",axis=1,inplace=True)


# In[68]:


df


# In[69]:


df["Degree"].unique()


# In[70]:


df["CollegeTier"].unique()


# In[71]:


df["Specialization"].value_counts()


# In[72]:


df["Specialization"].nunique()


# In[73]:


min(df["collegeGPA"])


# In[74]:


max(df["collegeGPA"])


# In[75]:


df[df["collegeGPA"]<50][['GraduationYear',"collegeGPA"]]


# In[76]:


df.columns


# In[77]:


df.columns


# In[78]:


df["CollegeCityTier"].unique()


# In[79]:


df["Degree"].unique()


# In[80]:


max(df["Logical"].unique())


# In[81]:


min(df["Logical"].unique())


# In[82]:


max(df["Quant"].unique())


# In[83]:


min(df["Quant"].unique())


# In[84]:


max(df["Domain"])


# In[85]:


min(df["Domain"])


# In[ ]:





# In[86]:


def board(x):
    if ((x=="cbse")|(x=="'all india board'")|(x=="central board of secondary education, new delhi")|(x=="cbese")):
        return "cbse"
    elif ((x=="isc")|(x=="icse")|(x=="isc board")|(x=="isce")|(x=="cicse")|(x=="isc board")|(x=="new delhi")):
        return "icse"
    elif x=="0":
        return "cbse"
    else:
        return "state board"


# In[87]:


df["12board"]=df["12board"].apply(board)


# In[88]:


df["12board"].unique()


# In[89]:


df["12board"].value_counts()


# In[90]:


df.columns


# In[91]:


df["Specialization"].unique()


# In[92]:


df[df['Specialization'].str.contains("computer")]["Specialization"].unique()


# In[93]:


df[df['Specialization'].str.contains("electronics")]["Specialization"].unique()


# In[94]:


df[df['Specialization'].str.contains("electrical")]["Specialization"].unique()


# In[95]:


df[df['Specialization'].str.contains("information")]["Specialization"].unique()


# In[96]:


df[df['Specialization'].str.contains("mechanical")]["Specialization"].unique()


# In[97]:


df[df['Specialization'].str.contains("civil")]["Specialization"].unique()


# In[98]:


def Specialization(x):
    if (x=="computer engineering")|(x=="computer science & engineering")|(x=="computer application")|(x=="electronics and computer engineering")|(x=="computer science and technology")|(x=="computer and communication engineering")|(x=="computer networking")|(x=="computer science"):
        return "cse"
    elif (x=="electronics and communication engineering")|(x=="electronics & telecommunications")|(x=="electronics engineering")|(x=="electronics"):
        return "ece"
    elif (x=="applied electronics and instrumentation")|(x=="electronics & instrumentation eng")|(x=="electronics and instrumentation engineering"):
        return "eie"
    elif (x=="electronics and electrical engineering")|(x=="electrical engineering")|(x=="electrical and power engineering"):
        return "eie"
    elif (x=="information technology")|(x=="information science engineering")|(x=="information & communication technology")|(x=="information science"):
        return "it"
    elif (x=="mechanical engineering")|(x=="mechanical and automation")|(x=="mechanical & production engineering"):
        return "me"
    elif (x=="civil engineering"):
        return "ce"
    else:
        return "other"
    
        
    
    


# In[99]:


df['Specialization']=df['Specialization'].apply(Specialization)


# In[100]:


df['Specialization'].unique()


# In[101]:


df['Specialization'].value_counts()


# In[102]:


df.columns


# In[103]:


min(df["collegeGPA"].unique())


# In[104]:


df.columns


# In[105]:


df[df['collegeGPA']<40]["collegeGPA"]


# In[106]:


df["CollegeCityTier"].unique()


# In[107]:


df["CollegeID"].nunique()


# In[108]:


df["Degree"].unique()


# In[109]:


df["Specialization"].unique()


# In[110]:


df["CollegeState"].unique()


# In[111]:


df['GraduationYear'].unique()


# In[112]:


df[df['GraduationYear']==0]


# In[113]:


df['GraduationYear'].value_counts()


# In[114]:


df.columns


# In[115]:


df['GraduationYear']=df['GraduationYear'].replace(0,2013)


# In[116]:


df.describe()


# In[117]:


df.describe(include="object")


# In[118]:


df["Designation"].unique()


# In[119]:


df[df["Designation"].str.contains("software")]["Designation"].unique()


# In[120]:


df[df["Designation"].str.contains("test")]["Designation"].unique()


# In[ ]:





# In[121]:


df["Designation"].value_counts()


# In[122]:


df


# In[123]:


df[df["Designation"].str.contains("test")]


# In[124]:


df.columns


# In[125]:


max(df["collegeGPA"])


# In[126]:


min(df["collegeGPA"])


# In[127]:


df.columns


# In[128]:


df['GraduationYear'].unique()


# In[129]:


df["CollegeID"].nunique()


# In[130]:


df["English"].unique()


# In[131]:


sum(df["Logical"].unique()==0)


# In[132]:


df["Logical"].unique()


# In[133]:


sum(df["Quant"].unique()==0)


# In[134]:


df["Quant"].unique()


# In[135]:


sum(df["Domain"].unique()==0)


# In[136]:


sns.kdeplot(data=df,x="Salary")
plt.xticks()


# In[137]:


df


# In[138]:


df1=df["JobCity"].value_counts().reset_index()


# In[139]:


df1=df1.sort_values("count",ascending=False)


# In[140]:


df2=df1.head(10)


# In[141]:


sns.barplot(data=df2,x="JobCity",y="count")
plt.xticks(rotation=90)
plt.show()


# In[142]:


df3=df["Designation"].value_counts().reset_index()
df3=df3.sort_values("count",ascending=False)


# In[143]:


df4=df3.head(10)


# In[144]:


sns.barplot(data=df4,x="Designation",y="count")
plt.xticks(rotation=90)
plt.show()


# In[145]:


df5=df.groupby("Designation")["Salary"].sum().reset_index()
df5=df5.sort_values("Salary",ascending=False)


# In[146]:


df6=df5.head(10)
df6


# In[147]:


sns.barplot(data=df6,x="Designation",y="Salary")
plt.xticks(rotation=90)
plt.show()


# In[148]:


df


# In[149]:


df7=df.groupby(["Designation","Gender"])["Salary"].sum().reset_index()


# In[150]:


df7=df7.sort_values("Salary",ascending=False)


# In[151]:


df7


# In[152]:


df


# In[153]:


sns.lineplot(data=df,x="DOJ",y="Salary")


# In[154]:


df


# In[155]:


df9=df.groupby("Gender")["Salary"].sum().reset_index()
df9


# In[156]:


sns.barplot(data=df9,x="Gender",y="Salary",width=0.4)


# In[157]:


df


# In[158]:


df10=df.groupby("10board")["Salary"].sum().reset_index()
df10=df10.sort_values("Salary")


# In[159]:


sns.barplot(data=df10,x="10board",y="Salary",width=0.4)


# In[160]:


plt.boxplot(df["Salary"])
plt.show()


# In[161]:


max(df["Salary"])


# In[162]:


df11=df.groupby("12board")["Salary"].sum().reset_index()
df11=df11.sort_values("Salary")


# In[163]:


sns.barplot(data=df11,x="12board",y="Salary",width=0.4)


# In[164]:


df.columns


# In[165]:


df12=df.groupby("Specialization")["Salary"].sum().reset_index()
df12=df12.sort_values("Salary",ascending=False)


# In[166]:


sns.barplot(data=df12,x="Specialization",y="Salary")


# In[167]:


df13=df.groupby("Degree")["Salary"].sum().reset_index()
df13=df13.sort_values("Salary",ascending=False)


# In[168]:


sns.barplot(data=df13,x="Degree",y="Salary",)


# In[169]:


df


# In[170]:


sns.kdeplot(df['10percentage'])


# In[171]:


sns.kdeplot(df['12percentage'])


# In[172]:


df.columns


# In[173]:


df14=df[df["ComputerProgramming"]!=0]


# In[174]:


plt.hist(df["ComputerProgramming"])
plt.show()


# In[175]:


min(df["Salary"])


# In[176]:


df.to_csv("cleaned_data.csv")


# In[177]:


import os


# In[178]:


os.getcwdb()


# In[179]:


plt.hist(df["Salary"])
plt.show()


# In[180]:


df["Salary"].mean()


# In[181]:


df[df["Salary"]<307699.8499249625]


# In[182]:


df["Designation"].unique()


# In[183]:


df[df["Designation"].str.contains("software")]["Designation"].unique()


# In[184]:


df[df["Designation"].str.contains("customer")]["Designation"].unique()


# In[185]:


def Designation1(x):
    if (x == "system engineer") | (x == "assistant system engineer") | (x == "associate system engineer") | (x == "system engineer trainee") | (x == "assistant system engineer trainee") | (x == "assistant system engineer - trainee") | (x == "systems engineer") | (x == "senior systems engineer"):
        return "system engineer"
    elif (x == "test engineer") | (x == "software test engineer") | (x == "manual tester") | (x == "software tester") | (x == "testing engineer") | (x == "associate test engineer") | (x == "associate test engineer") | (x == "software test engineerte") | (x == "software test engineer (etl)") | (x == "website developer/tester") | (x == "senior test engineer") | (x == "test technician"):
        return "test engineer"
    elif (x == "senior quality engineer") | (x == "quality assurance engineer") | (x == "quality engineer") | (x == "quality analyst") | (x == "quality assurance automation engineer") | (x == "quality control engineer") | (x == "software quality assurance tester") | (x == "software quality assurance analyst") | (x == "quality assurance test engineer") | (x == "quality assurance tester") | (x == "quality associate") | (x == "quality controller") | (x == "quality assurance auditor") | (x == "senior quality assurance engineer") | (x == "quality assurance") | (x == "quality control inspector") | (x == "quality control inspection technician") | (x == "quality assurance analyst") | (x == "quality consultant") | (x == "qa analyst"):
        return "quality engineer"
    elif (x == "programmer analyst") | (x == "systems analyst") | (x == "data analyst") | (x == "research analyst") | (x == "business analyst") | (x == "business process analyst") | (x == "programmer analyst trainee") | (x == "it analyst") | (x == "business technology analyst") | (x == "business analyst consultant") | (x == "marketing analyst") | (x == "senior business analyst") | (x == "senior business analyst") | (x == "system analyst") | (x == "software engineer analyst") | (x == "technical operations analyst") | (x == "technology analyst") | (x == "it business analyst") | (x == "junior system analyst") | (x == "information security analyst") | (x == "business intelligence analyst") | (x == "technical analyst") | (x == "business system analyst") | (x == "sap analyst") | (x == "software analyst") | (x == "desktop support analyst") | (x == 'business systems analyst') | (x == "financial analyst") | (x == "supply chain analyst") | (x == "seo analyst") | (x == "program analyst trainee"):
        return "analyst"
    elif (x == "network engineer") | (x == "network administrator") | (x == "network security engineer") | (x == "senior network engineer") | (x == "network support engineer"):
        return "network engineer"
    elif (x == 'sales associate') | (x == 'sales engineer') | (x == 'sales executive') | (x == 'entry level sales and marketing') | (x == 'service and sales engineer') | (x == 'salesforce developer') | (x == 'sales management trainee') | (x == 'sales and service engineer') | (x == 'sales account manager') | (x == 'sales support') | (x == 'territory sales manager') | (x == 'sales development manager') | (x == 'sales & service engineer') | (x == 'sales manager') | (x == 'sales trainer') | (x == 'sales coordinator') | (x == 'senior sales executive'):
        return "sales"
    elif (x == 'electrical engineer') | (x == 'electrical project engineer') | (x == 'electrical designer') | (x == 'electrical design engineer') | (x == 'electrical field engineer') | (x == 'lecturer & electrical maintenance') | (x == 'assistant electrical engineer') | (x == 'electrical controls engineer'):
        return "electrical engineer"
    elif (x == 'customer service') | (x == 'customer service representative') | (x == 'engineer- customer support') | (x == 'customer service manager') | (x == 'customer support engineer') | (x == 'customer care executive'):
        return "customer service"
    elif (x == 'senior software engineer') | (x == 'java software engineer') | (x == 'associate software developer') | (x == 'software engineer') | (x == 'associate software engineer') | (x == 'software developer') | (x == 'jr. software engineer') | (x == 'trainee software developer') | (x == 'assistant software engineer') | (x == 'junior software engineer') | (x == 'trainee software engineer') | (x == 'senior software developer') | (x == 'software development engineer') | (x == 'software architect') | (x == 'software trainee') | (x == 'junior software developer') | (x == 'software trainee engineer') | (x == 'software tester') | (x == 'principal software engineer') | (x == 'software devloper') | (x == 'software engineer trainee') | (x == 'software enginner') | (x == 'delivery software engineer') | (x == 'software engineer associate') | (x == 'software engineere') | (x == 'software analyst') | (x == 'software programmer') | (x == 'software engg') | (x == 'associate software engg') | (x == 'software executive') | (x == 'software designer') | (x == 'software eng') | (x == 'software engineering associate') | (x == 'jr. software developer'):
        return "software engineer"
    else:
        return "others"


# In[186]:


df[df["Designation"]=="quality control inspection technician"]["ComputerProgramming"]


# In[187]:


df.columns


# In[188]:


df['Designation']=df['Designation'].apply(Designation1)


# In[189]:


df['Designation'].unique()


# In[190]:


sns.pairplot(data=df)


# In[191]:


sns.barplot(data=df,x="Designation",y="Salary")
plt.xticks(rotation=90)
plt.show()


# In[192]:


df.columns


# In[193]:


for column in df.select_dtypes(include='number').columns:
    plt.figure(figsize=(8, 6))
    plt.hist(df[column], bins=10, color='blue', edgecolor='black')
    plt.title(f'Histogram for {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.show()


# In[194]:


df.drop("ID",axis=1,inplace=True)


# In[195]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='number').columns:
    plt.figure(figsize=(8, 6))
    sns.displot(df[column], color='blue', fill=True,kind='hist')
    plt.title(f'KDE Plot for {column}')
    plt.xlabel(column)
    plt.ylabel('Density')
    plt.show()


# In[196]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='number').columns:
    plt.figure(figsize=(8, 6))
    
    # Histogram
    sns.histplot(df[column], bins=10, color='blue', edgecolor='black',)
    
    # KDE plot
    sns.kdeplot(df[column], color='red', fill=True, label='KDE')
    
    plt.title(f'Histogram and KDE Plot for {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency/Density')
    plt.legend()
    
    plt.show()


# In[197]:


sns.distplot(df["Salary"])


# In[198]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='number').columns:
    plt.figure(figsize=(8, 6))
    
    # Using sns.distplot for combined histogram and KDE plot
    sns.distplot(df[column], bins=10, hist_kws={'color': 'blue', 'edgecolor': 'black'}, kde_kws={'color': 'red', 'fill': True}, label='Combined Plot')
    
    plt.title(f'Combined Histogram and KDE Plot for {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency/Density')
    plt.legend()
    
    plt.show()


# In[199]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='object').columns:
    plt.figure(figsize=(8, 6))
    
    # Using sns.countplot for count plot
    sns.countplot(data=df, x=column, palette='viridis')
    
    plt.title(f'Count Plot for {column}')
    plt.xlabel(column)
    plt.ylabel('Count')
    plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
    
    plt.show()


# In[200]:


import plotly.express as px

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='object').columns:
    
    # Using Plotly Express to create count plot
    fig = px.bar(df, x=column, title=f'Count Plot for {column}', labels={'x': column, 'y': 'Count'},
                 color=column, color_discrete_sequence="smoker")
    
    fig.update_layout(xaxis=dict(tickangle=45))  # Rotate x-axis labels for better readability
    
    fig.show()


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='object').columns:
    plt.figure(figsize=(10, 6))
    
    # Get the top 10 categories
    top_categories = df[column].value_counts().nlargest(10).index
    
    # Filter the DataFrame for the top 10 categories
    df_top10 = df[df[column].isin(top_categories)]
    
    # Using sns.countplot for count plot
    sns.countplot(data=df_top10, x=column, palette='viridis', order=top_categories)
    
    plt.title(f'Top 10 Count Plot for {column}')
    plt.xlabel(column)
    plt.ylabel('Count')
    plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
    
    plt.show()


# In[ ]:


import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='object').columns:
    plt.figure(figsize=(8, 8))
    
    # Get value counts for the categorical variable
    counts = df[column].value_counts()
    
    # Extract top 10 categories
    top_categories = counts.nlargest(10).index
    
    # Filter the DataFrame for the top 10 categories
    df_top10 = df[df[column].isin(top_categories)]
    
    # Create a pie chart
    plt.pie(counts.loc[top_categories], labels=top_categories, autopct='%1.1f%%', startangle=140, colors=plt.cm.viridis.colors)
    
    plt.title(f'Pie Chart for {column}')
    
    plt.show()


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='object').columns:
    plt.figure(figsize=(8, 8))
    
    # Get value counts for the categorical variable
    counts = df[column].value_counts()
    
    # Extract top 10 categories
    top_categories = counts.nlargest(10).index
    
    # Filter the DataFrame for the top 10 categories
    df_top10 = df[df[column].isin(top_categories)]
    
    # Create a pie chart with a gradient colormap
    colors = sns.color_palette("viridis", n_colors=len(top_categories))
    plt.pie(counts.loc[top_categories], labels=top_categories, autopct='%1.1f%%', startangle=140, colors=colors)
    
    plt.title(f'Pie Chart for {column}')
    
    plt.show()


# In[ ]:


import plotly.express as px
import pandas as pd

# Assuming 'df' is your DataFrame
for column in df.select_dtypes(include='object').columns:
    
    # Get value counts for the categorical variable
    counts = df[column].value_counts()
    
    # Extract top 10 categories
    top_categories = counts.nlargest(10).index
    
    # Filter the DataFrame for the top 10 categories
    df_top10 = df[df[column].isin(top_categories)]
    
    # Create a Pie chart with Plotly
    fig = px.pie(df_top10, names=column, title=f'Pie Chart for {column}', 
                 labels=top_categories, hole=0.3, color_discrete_sequence=px.colors.sequential.Viridis)
    
    fig.show()


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
numerical_columns = df.select_dtypes(include='number').columns

for column in numerical_columns:
    plt.figure(figsize=(8, 6))
    
    # Using sns.boxplot for box plot
    sns.boxplot(x=df[column], color='skyblue')
    
    plt.title(f'Box Plot for {column}')
    plt.xlabel(column)
    
    plt.show()


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            plt.figure(figsize=(12, 8))
            
            # Using groupby and sns.barplot for bar plot with two categorical variables
            grouped_data = df.groupby([cat_column1, cat_column2])[numerical_columns[0]].mean().reset_index()
            sns.barplot(x=cat_column1, y=numerical_columns[0], hue=cat_column2, data=grouped_data, palette='Set2')
            
            plt.title(f'Bar Plot for {cat_column1} and {cat_column2}')
            plt.xlabel(cat_column1)
            plt.ylabel(f'{numerical_columns[0]} (Mean)')
            
            plt.show()


# In[ ]:


import plotly.express as px

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical column
            grouped_data = df.groupby([cat_column1, cat_column2])[numerical_columns[0]].mean().reset_index()
            
            # Create a bar plot with Plotly
            fig = px.bar(grouped_data, x=cat_column1, y=numerical_columns[0], color=cat_column2,
                         title=f'Bar Plot for {cat_column1} and {cat_column2}', barmode='group')
            
            # Rotate x-axis tick labels
            fig.update_layout(xaxis=dict(tickangle=45))
            
            fig.show()


# In[ ]:


import plotly.express as px

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical column
            grouped_data = df.groupby([cat_column1, cat_column2])[numerical_columns[0]].mean().reset_index()
            
            # Get the top 10 combinations
            top_combinations = grouped_data.groupby(cat_column1)[numerical_columns[0]].mean().nlargest(10).index
            grouped_data_top10 = grouped_data[grouped_data[cat_column1].isin(top_combinations)]
            
            # Create a bar plot with Plotly for the top 10 combinations
            fig = px.bar(grouped_data_top10, x=cat_column1, y=numerical_columns[0], color=cat_column2,
                         title=f'Bar Plot for {cat_column1} and {cat_column2} (Top 10)', barmode='group')
            
            # Rotate x-axis tick labels
            fig.update_layout(xaxis=dict(tickangle=45))
            
            fig.show()


# In[ ]:


import plotly.express as px

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical column
            grouped_data = df.groupby([cat_column1, cat_column2])[numerical_columns[0]].mean().reset_index()
            
            # Sort the data by the numerical column
            grouped_data_sorted = grouped_data.sort_values(by=numerical_columns[0], ascending=False)
            
            # Get the top 10 combinations for each group in the first categorical column
            top_combinations = grouped_data_sorted.groupby(cat_column1).head(10)[cat_column1].unique()
            grouped_data_top10 = grouped_data_sorted[grouped_data_sorted[cat_column1].isin(top_combinations)]
            
            # Create a bar plot with Plotly for the top 10 combinations
            fig = px.bar(grouped_data_top10, x=cat_column1, y=numerical_columns[0], color=cat_column2,
                         title=f'Bar Plot for {cat_column1} and {cat_column2} (Top 10)', barmode='group')
            
            # Rotate x-axis tick labels
            fig.update_layout(xaxis=dict(tickangle=90))
            
            fig.show()


# In[ ]:


df.corr(numeric_only=True)


# In[ ]:


sns.heatmap(df.corr(numeric_only=True))


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
numeric_columns = df.select_dtypes(include='number').columns

# Create a correlation matrix
correlation_matrix = df[numeric_columns].corr()

# Set up the matplotlib figure
plt.figure(figsize=(12, 10))

# Create a heatmap with a color gradient, and adjust the width of the x and y axes
sns.heatmap(correlation_matrix, cmap='coolwarm', annot=True, linewidths=.5, vmin=-1, vmax=1)

# Rotate the y-axis labels for better readability
plt.yticks(rotation=0)

# Show the plot
plt.show()


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Create a cross-tabulation (count of combinations) using pd.crosstab
            cross_tab = pd.crosstab(index=df[cat_column1], columns=df[cat_column2])
            
            plt.figure(figsize=(12, 8))
            
            # Using sns.heatmap for visualization
            sns.heatmap(cross_tab, annot=True, cmap='Blues', fmt='g')
            
            plt.title(f'Cross Tabulation Heatmap for {cat_column1} and {cat_column2}')
            plt.xlabel(cat_column2)
            plt.ylabel(cat_column1)
            
            plt.show()


# In[ ]:


# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Create a cross-tabulation (count of combinations) using pd.crosstab
            cross_tab = pd.crosstab(index=df[cat_column1], columns=df[cat_column2])
            
            # Display the cross-tabulation as a table
            display(cross_tab)


# In[ ]:


categorical_columns=df.select_dtypes(include="object").columns


# In[ ]:


categorical_columns


# In[ ]:





# In[ ]:


for i in categorical_columns:
    for j in categorical_columns:
        if i!=j:
            crosstab=pd.crosstab(index=df[i],columns=df[j],values=df["Salary"],aggfunc=np.mean,margins=True).reset_index()
            display(crosstab)


# In[ ]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two numerical columns for hexbin plot
numerical_column1 = numerical_columns[0]
numerical_column2 = numerical_columns[1]

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical columns separately
            grouped_data1 = df.groupby([cat_column1, cat_column2])[numerical_column1].mean().reset_index()
            grouped_data2 = df.groupby([cat_column1, cat_column2])[numerical_column2].mean().reset_index()
            
            # Merge the two grouped data on the categorical columns
            grouped_data = pd.merge(grouped_data1, grouped_data2, on=[cat_column1, cat_column2])
            
            # Sort the data by the numerical column1
            grouped_data_sorted = grouped_data.sort_values(by=numerical_column1, ascending=False)
            
            # Get the top 10 combinations for each group in the first categorical column
            top_combinations = grouped_data_sorted.groupby(cat_column1).head(10)[cat_column1].unique()
            grouped_data_top10 = grouped_data_sorted[grouped_data_sorted[cat_column1].isin(top_combinations)]
            
            plt.figure(figsize=(12, 8))
            
            # Using sns.jointplot for hexbin plot
            sns.jointplot(x=numerical_column1, y=numerical_column2, data=grouped_data_top10, kind='hex', cmap='Blues')
            
            plt.title(f'Hexbin Plot for {numerical_column1} and {numerical_column2} based on {cat_column1} and {cat_column2} (Top 10)')
            
            plt.show()


# In[ ]:


import plotly.express as px

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two numerical columns for hexbin plot
numerical_column1 = numerical_columns[0]
numerical_column2 = numerical_columns[1]

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical columns separately
            grouped_data1 = df.groupby([cat_column1, cat_column2])[numerical_column1].mean().reset_index()
            grouped_data2 = df.groupby([cat_column1, cat_column2])[numerical_column2].mean().reset_index()
            
            # Merge the two grouped data on the categorical columns
            grouped_data = pd.merge(grouped_data1, grouped_data2, on=[cat_column1, cat_column2])
            
            # Sort the data by the numerical column1
            grouped_data_sorted = grouped_data.sort_values(by=numerical_column1, ascending=False)
            
            # Get the top 10 combinations for each group in the first categorical column
            top_combinations = grouped_data_sorted.groupby(cat_column1).head(10)[cat_column1].unique()
            grouped_data_top10 = grouped_data_sorted[grouped_data_sorted[cat_column1].isin(top_combinations)]
            
            # Create hexbin plot using Plotly Express
            fig = px.scatter(grouped_data_top10, x=numerical_column1, y=numerical_column2, color=cat_column1,
                             marginal_x='histogram', marginal_y='histogram',
                             title=f'Hexbin Plot for {numerical_column1} and {numerical_column2} based on {cat_column1} and {cat_column2} (Top 10)',
                             labels={'color': cat_column1}, color_continuous_scale='Blues')
            
            fig.show()


# In[ ]:


import plotly.express as px

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two numerical columns for scatter plot
numerical_column1 = numerical_columns[0]
numerical_column2 = numerical_columns[1]

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical columns separately
            grouped_data1 = df.groupby([cat_column1, cat_column2])[numerical_column1].mean().reset_index()
            grouped_data2 = df.groupby([cat_column1, cat_column2])[numerical_column2].mean().reset_index()
            
            # Merge the two grouped data on the categorical columns
            grouped_data = pd.merge(grouped_data1, grouped_data2, on=[cat_column1, cat_column2])
            
            # Sort the data by the numerical column1
            grouped_data_sorted = grouped_data.sort_values(by=numerical_column1, ascending=False)
            
            # Get the top 10 combinations for each group in the first categorical column
            top_combinations = grouped_data_sorted.groupby(cat_column1).head(10)[cat_column1].unique()
            grouped_data_top10 = grouped_data_sorted[grouped_data_sorted[cat_column1].isin(top_combinations)]
            
            # Create scatter plot using Plotly Express
            fig = px.scatter(grouped_data_top10, x=numerical_column1, y=numerical_column2, color=cat_column1,
                             title=f'Scatter Plot for {numerical_column1} and {numerical_column2} based on {cat_column1} and {cat_column2} (Top 10)',
                             labels={'color': cat_column1}, color_continuous_scale='Viridis')
            
            fig.show()


# In[ ]:


df.columns


# In[ ]:


df["CollegeState"].unique()


# In[ ]:


df


# In[ ]:





# In[ ]:


import matplotlib.pyplot as plt
import seaborn as sns

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two numerical columns for violin plot
numerical_column1 = numerical_columns[0]
numerical_column2 = numerical_columns[1]

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical columns separately
            grouped_data1 = df.groupby([cat_column1, cat_column2])[numerical_column1].mean().reset_index()
            grouped_data2 = df.groupby([cat_column1, cat_column2])[numerical_column2].mean().reset_index()
            
            # Merge the two grouped data on the categorical columns
            grouped_data = pd.merge(grouped_data1, grouped_data2, on=[cat_column1, cat_column2])
            
            # Sort the data by the numerical column1
            grouped_data_sorted = grouped_data.sort_values(by=numerical_column1, ascending=False)
            
            # Get the top 10 combinations for each group in the first categorical column
            top_combinations = grouped_data_sorted.groupby(cat_column1).head(10)[cat_column1].unique()
            grouped_data_top10 = grouped_data_sorted[grouped_data_sorted[cat_column1].isin(top_combinations)]
            
            # Create violin plot using Matplotlib
            plt.figure(figsize=(12, 8))
            sns.violinplot(x=cat_column1, y=numerical_column1, data=grouped_data_top10, inner='quartile')
            plt.title(f'Violin Plot for {numerical_column1} based on {cat_column1} and {cat_column2} (Top 10)')
            plt.xticks(rotation=90)
            plt.show()


# In[ ]:





# In[ ]:


import matplotlib.pyplot as plt
import seaborn as sns

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose two numerical columns for swarm plot
numerical_column1 = numerical_columns[0]
numerical_column2 = numerical_columns[1]

# Choose two categorical columns (e.g., 'Category1' and 'Category2')
for cat_column1 in categorical_columns:
    for cat_column2 in categorical_columns:
        if cat_column1 != cat_column2:
            
            # Using groupby to calculate the mean for numerical columns separately
            grouped_data1 = df.groupby([cat_column1, cat_column2])[numerical_column1].mean().reset_index()
            grouped_data2 = df.groupby([cat_column1, cat_column2])[numerical_column2].mean().reset_index()
            
            # Merge the two grouped data on the categorical columns
            grouped_data = pd.merge(grouped_data1, grouped_data2, on=[cat_column1, cat_column2])
            
            # Sort the data by the numerical column1
            grouped_data_sorted = grouped_data.sort_values(by=numerical_column1, ascending=False)
            
            # Get the top 10 combinations for each group in the first categorical column
            top_combinations = grouped_data_sorted.groupby(cat_column1).head(10)[cat_column1].unique()
            grouped_data_top10 = grouped_data_sorted[grouped_data_sorted[cat_column1].isin(top_combinations)]
            
            # Create swarm plot using Seaborn in Matplotlib
            plt.figure(figsize=(12, 8))
            sns.swarmplot(x=cat_column1, y=numerical_column1, data=grouped_data_top10)
            plt.title(f'Swarm Plot for {numerical_column1} based on {cat_column1} and {cat_column2} (Top 10)')
            plt.show()


# In[ ]:


df


# In[ ]:


sns.scatterplot(data=df,x="10percentage",y="12percentage")


# In[ ]:


df.columns

Times of India article dated Jan 18, 2019 states that “After doing your Computer Science Engineering if you take up jobs as a Programming Analyst, Software Engineer, Hardware Engineer and Associate Engineer you can earn up to 2.5-3 lakhs as a fresh graduate.” Test this claim with the data given to you.
 

# In[ ]:


df["Specialization"].unique()


# In[ ]:


df[df["Specialization"]=="cse"]["Salary"].mean()


# hence proved 
# 

# Is there a relationship between gender and specialization?(i.e. Does the preference of Specialisation depend on the Gender?)

# In[ ]:


pd.crosstab(index=df["Gender"],columns=df["Specialization"])


# **the both the men and women are intrested in the cse that is computer science and engineering**

# In[ ]:





# In[ ]:


category_columns=df.select_dtypes(include="object").columns


# In[ ]:


numerical_columns=df.select_dtypes(include="number").columns


# In[ ]:


for i in category_columns:
    for j in numerical_columns:
        groupby=df.groupby(i)[j].mean().reset_index()
        groupby=groupby.sort_values(by=j,ascending=False)
        
        display(groupby)


# In[ ]:


import matplotlib.pyplot as plt
import seaborn as sns

# Assuming 'df' is your DataFrame
categorical_columns = df.select_dtypes(include='object').columns
numerical_columns = df.select_dtypes(include='number').columns

# Choose one numerical column for bar plot
numerical_column = numerical_columns[0]

# Iterate through each combination of categorical and numerical columns
for i in categorical_columns:
    for j in numerical_columns:
        if i != j:
            # Using groupby to calculate the mean for the numerical column
            groupby_data = df.groupby(i)[j].mean().reset_index()
            
            # Plotting bar plot using Seaborn
            plt.figure(figsize=(12, 6))
            sns.barplot(x=i, y=j, data=groupby_data)
            plt.title(f'Bar Plot for {j} based on {i}')
            plt.xticks(rotation=90)
            plt.xlabel(i)
            plt.ylabel(j)
            plt.show()


# In[ ]:


for i in categorical_columns:
    for j in numerical_columns:
        if i != j:
            # Using groupby to calculate the mean for the numerical column
            groupby_data = df.groupby(i)[j].mean().reset_index()
            groupby_data = groupby_data.sort_values(by=j, ascending=False)
            
            # Plotting bar plot using Seaborn
            plt.figure(figsize=(12, 6))
            sns.barplot(data=groupby_data, x=i, y=j)
            plt.title(f'Bar Plot for {j} based on {i}')
            plt.xlabel(i)
            plt.ylabel(j)
            plt.xticks(rotation=90)
            plt.show()
            
            # Display the grouped data table
            display(groupby_data)


# In[ ]:


df


# In[ ]:


df[df["Designation"]=="software engineer"]["Salary"].mean()


# In[ ]:


df[df["Designation"]=="analyst"]["Salary"].mean()


# In[202]:


df.info()


# In[ ]:




